<?php 
	session_destroy();