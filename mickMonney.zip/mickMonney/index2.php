<!DOCTYPE html>
<html>
<head>
	<title>::MickMo</title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=divice-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.3/jquery.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?familly=lato">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/script.js"></script>
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="col-lg-8">
					<div class="col-md-12">
						<nav>
							<ul id="menu">
								<li><a href="index2.php" class="nav-list">Home</a></li>
								<li><a href="depot.php" class="nav-list">Dépôt</a></li>
								<li><a href="retrait.php" class="nav-list">Retrait</a></li>
								<li><a href="#" class="nav-list">Mon compte</a></li>
								<li><a href="logout.php" class="nav-list">Déconnexion</a></li>
							</ul>
						</nav>
					</div>
				</div>

				<div class="col-lg-4">
					<div class="col-md-12">
						<div class="logo">
							<h2><a href="index2.php">Mick Money</a></h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<section class="home">
		<div class="container">
				<div class="home-text">
					<h1>Mick Mo</h1>
				</div>
		</div>
	</section>
	</body>
</html>