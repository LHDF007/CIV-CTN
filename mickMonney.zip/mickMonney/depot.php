<header>
		<div class="container">
			<div class="row">
				<div class="col-lg-8">
					<div class="col-md-12">
						<nav>
							<ul id="menu">
								<li><a href="index2.php" class="nav-list">Home</a></li>
								<li><a href="#" class="nav-list">Retrait</a></li>
								<li><a href="#" class="nav-list">Mon compte</a></li>
								<li><a href="logout.php" class="nav-list">Déconnexion</a></li>
							</ul>
						</nav>
					</div>
				</div>

				<div class="col-lg-4">
					<div class="col-md-12">
						<div class="logo">
							<h2><a href="../index2.php">Mick Money</a></h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<section>
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="col-md-12">
						<button style="text-align: center; margin-top: 40%; background: orange; border-style: none; height: 50px; width: 200px; border-radius: 10px;"><a href="orange.php" style="text-transform: uppercase; color: #fff; text-decoration: none; font-weight: bold;">Par Orange Money</a></button>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="col-md-12">
						<button style="text-align: center; margin-top: 40%; background: green; border-style: none; height: 50px; width: 200px; border-radius: 10px;"><a href="depot2.php" style="text-transform: uppercase; color: #fff; text-decoration: none; font-weight: bold;">à un utilisateur</a></button>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php require 'inc/footer.php' ?>