<!DOCTYPE html>
<html>
<head>
	<title>::MickMo</title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=divice-width, initial-scale=1">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.3/jquery.min.js"></script>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?familly=lato">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
					<p style="color: #fff; font-weight: bold;">Copyrigth Tout droits résevés</p>
			</div>
		</div>
	</header>
</body>
</html>