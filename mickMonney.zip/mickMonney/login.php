<?php require 'inc/header.php' ?>


 <div class="container">
 	<form action="" method="POST">
			<div class="form-group">
				<label for="">Pseudo</label>
				<input type="text" name="username" class="form-control">
			</div>

			<div class="form-group">
				<label for="">Mot de Passse</label>
				<input type="password" name="password" class="form-control">
			</div>

			<button type="submit" class="btn btn-primary">Se connecter</button>
			</form>
		<br><br>
 </div>